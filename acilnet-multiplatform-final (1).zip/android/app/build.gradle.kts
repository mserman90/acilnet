
plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.acilnet.mesh"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.acilnet.mesh"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0-acilnet"
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.10.0")
    implementation("com.google.android.gms:play-services-nearby:19.2.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
}
